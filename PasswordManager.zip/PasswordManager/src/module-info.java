/**
 * 
 */
/**
 * @author cellolian
 *
 */
module PasswordManager {
	requires java.desktop;
	requires java.datatransfer;
}