package PasswordManager;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;

public class FileIO {
	
	private String file_path;
	private File f;
	private String fileDir = "data";

	public FileIO(String filename) {
		// ディレクトリがない場合は生成
		File d = new File(fileDir);
		if (!d.exists())
			d.mkdir();
		// ファイルがない場合も生成
		file_path = d.getPath() + "/" + filename + ".json";
		f = new File(file_path);
		if (!f.exists())
			_mkfile(f);
	}

	public String readFile() {
		try {
			BufferedReader br = new BufferedReader(new FileReader(f));
			String data = "";
			String str = br.readLine();
			while (str != null) {
				data += str;
				str = br.readLine();
			}
			br.close();
			return data;
		} catch (FileNotFoundException e) {
			System.out.println(e);
			return null;
		} catch (IOException e) {
			System.out.println(e);
			return null;
		}
	}

	private void _mkfile(File f) {
		try {
			f.createNewFile();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public Boolean writeFile(String str) {
		try {
			PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter(f)));
			pw.print(str);
			pw.close();
			// バックアップデータ
			File d = new File(fileDir+"/backup");
			if (!d.exists())
				d.mkdir();
			String path = d.getPath() + "/" + LocalDate.now().toString() + ".json";
			File file = new File(path);
			if (!file.exists())
				_mkfile(file);
			pw = new PrintWriter(new BufferedWriter(new FileWriter(file)));
			pw.print(str);
			pw.close();
			return true;
		} catch (IOException e) {
			e.printStackTrace();
			return false;
		}
	}
}