package PasswordManager;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import org.json.JSONArray;
import org.json.JSONObject;

@SuppressWarnings("serial")
public class PanelDetail extends JPanel {
	int dataIndex;
	String data;
	String[] settings;
	JSONArray data_json;
	// 詳細エリアの表示順
	final int ROW_NUM = 5;
	final int TITLE_ROW = 0;
	final int PASSWORD_ROW = 1;
	final int UPDATE_ROW = 2;
	final int MEMO_ROW = 3;
	final int OLD_ROW = 4;
	// 詳細エリアのペイン
	LabelPane titlePanel;
	TextPane passwordPanel;
	LabelPane updatePanel;
	TextPane memoPanel;
	TextPane oldPanel;
	
	PanelDetail(){
		// ボタンのエリア
		JPanel buttonPane = new JPanel();
		JButton button_update = new JButton("更新");
		buttonPane.add(button_update);
		button_update.addActionListener(new ActionListener(){
	    public void actionPerformed(ActionEvent e) {
	    	data_json = new JSONArray(MainFrame.fIO.readFile());
	    	JSONObject jsonObject = data_json.getJSONObject(dataIndex);
		    settings = new String[2];
				for(int j=0;j<2;j++) { settings[j] = jsonObject.getJSONArray("setting").get(j).toString(); }
	    	updateDialog();
		  }
		});
		// 詳細のエリア
		JPanel detailPane = new JPanel();
		GridLayout layout = new GridLayout(ROW_NUM,1);
		detailPane.setLayout(layout);
		
		JPanel[] layoutPanels = new JPanel[ROW_NUM];
		for(int i=0;i<ROW_NUM;i++) { layoutPanels[i] = new JPanel(); }
		
		titlePanel = new LabelPane("タイトル");
		layoutPanels[TITLE_ROW].add(titlePanel.panel);
		passwordPanel = new TextPane("パスワード");
		layoutPanels[PASSWORD_ROW].add(passwordPanel.panel);
		updatePanel = new LabelPane("更新日");
		layoutPanels[UPDATE_ROW].add(updatePanel.panel);
		memoPanel = new TextPane("メモ");
		layoutPanels[MEMO_ROW].add(memoPanel.panel);
		oldPanel = new TextPane("旧パスワード");
		layoutPanels[OLD_ROW].add(oldPanel.panel);
		
		for(int i=0;i<ROW_NUM;i++) { detailPane.add(layoutPanels[i]);}
		add(detailPane);
		add(buttonPane,BorderLayout.NORTH);
	}
	// 項目のためのペイン
	private class Pane {
		JPanel panel;
		Pane(String str) {
			panel = new JPanel();
			panel.add(new JLabel(str + "："));
		}
	}
	private class LabelPane extends Pane{
		JLabel text;
		LabelPane(String str) {
			super(str);
			text = new JLabel();
			panel.add(text);
		}
	}
	private class TextPane extends Pane {
		JTextField text;
		TextPane(String str) {
			super(str);
			text = new JTextField(10);
			panel.add(text);
		}
	}
	void initPage(int dataIndex) {
		this.dataIndex = dataIndex;
		String[] data = PanelHome.dataArray[dataIndex];
		titlePanel.text.setText(data[MainFrame.TITLE_INDEX]);
		passwordPanel.text.setText(data[MainFrame.PASSWORD_INDEX]);
		updatePanel.text.setText(data[MainFrame.UPDATE_INDEX]);
		memoPanel.text.setText(data[MainFrame.MEMO_INDEX]);
		oldPanel.text.setText(data[MainFrame.OLD_INDEX]);
	}
	void updateDialog() {
		data = MainFrame.cryptoEditor.genRandData();
		String password = MainFrame.cryptoEditor.genPassword(data, settings);
  	JFrame frame = new JFrame();
  	JPanel panel = new JPanel();
  	GridLayout layout = new GridLayout(2,1);
  	panel.setLayout(layout);
  	panel.add(new JLabel(password));
  	panel.add(new JLabel("このパスワードで更新する"));
		int option = JOptionPane.showConfirmDialog(frame, panel);
  	switch(option) {
  	case 0:
  		// 更新
  		if(updateData()) {
	    	JOptionPane.showMessageDialog(frame, "更新しました！");
	    	MainFrame.frameController.toHome();
    		} else {
    			JOptionPane.showMessageDialog(frame, "保存に失敗しました！");
    		}
  		break;
  	case 1:
  		// パスワードを再生成
  		updateDialog();
  		break;
  	}
	}
	private boolean updateData() {
		JSONObject jsonObject = data_json.getJSONObject(dataIndex);
		
		JSONObject obj = new JSONObject();
		obj.put("title", jsonObject.get("title"));
		obj.put("update", LocalDate.now().toString());
		JSONArray jsonArr = new JSONArray();
		jsonArr.put(settings[0]);
		jsonArr.put(settings[1]);
		obj.put("setting",jsonArr);
		obj.put("data",data);
		obj.put("old_data",jsonObject.get("data"));
		obj.put("memo",jsonObject.get("memo"));
		
		JSONArray new_data = new JSONArray(); 
    for (int i=0;i<data_json.length();i++) {
    	if(i!=dataIndex) {
    		new_data.put(data_json.getJSONObject(i));
    	} else {
    		new_data.put(obj);
    	}
    }
		return MainFrame.fIO.writeFile(new_data.toString(2));
	}
}
