package PasswordManager;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;

@SuppressWarnings("serial")
public class PanelSetting extends JPanel implements ActionListener{
	
	NumPane numPanel;
	SelectPane selectPanel;
	CharPane charPanel;

	String[] charNames = {"英小文字","英大文字","数字","記号","Base58"};
	String[] charList = {
			"abcdefghijklmnopqrstuvwxyz",
			"ABCDEFGHIJKLMNOPQRSTUVWXYZ",
			"0123456789",
			"#$%()*+-./:;?@[]_{}~",
			"123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz"
	};
	
	PanelSetting(){
		// ボタンのエリア
		JPanel buttonPane = new JPanel();
		JButton button = new JButton("決定");
		buttonPane.add(button);
		button.addActionListener(new ActionListener(){
	    public void actionPerformed(ActionEvent e) {
	    	String[] settings = {(String) numPanel.combo.getSelectedItem(),charPanel.text.getText()};
	    	MainFrame.frameController.registerUpdate(settings);
		  }
		});
		// 設定項目のエリア
		int paneNum = 3;
		JPanel settingPane = new JPanel();
		GridLayout layout = new GridLayout(paneNum,0);
		settingPane.setLayout(layout);
		
		FlowLayout flowLayout = new FlowLayout();
		flowLayout.setAlignment(FlowLayout.LEFT);
		JPanel[] layoutPanels = new JPanel[paneNum];
		for(int i=0;i<paneNum;i++) { 
			layoutPanels[i] = new JPanel(); 
			layoutPanels[i].setLayout(flowLayout);
		}
		
		numPanel = new NumPane("文字数");
		layoutPanels[0].add(numPanel.panel);
		selectPanel = new SelectPane("使用文字");
		layoutPanels[1].add(selectPanel.panel);
		charPanel = new CharPane("凡例(直接記入も可)");
		layoutPanels[2].add(charPanel.panel);
		
		for(int i=0;i<paneNum;i++) { settingPane.add(layoutPanels[i]);}
		add(settingPane);
		add(buttonPane,BorderLayout.SOUTH);
		
		for(int i=0;i<selectPanel.boxNum;i++){ selectPanel.boxs[i].addActionListener(this); }
		
	}
	void initPage() {} 
	
	private class Pane {
		JPanel panel;
		Pane(String str) {
			panel = new JPanel();
			panel.add(new JLabel(str + "："));
		}
	}
	private class NumPane extends Pane {
		String[] numList = {"4","6","8","12","16","20","30","50"};
		JComboBox<String> combo;
		NumPane(String str) {
			super(str);
			combo = new JComboBox<String>(numList);
			combo.setSelectedIndex(4);
			panel.add(combo);
		}
	}
	private class SelectPane extends Pane {
		int boxNum = 5;
		Boolean[] isChecked = {false, false, false, true, true};
		JCheckBox[] boxs = new JCheckBox[5];
		SelectPane(String str) {
			super(str);
			GridLayout layout = new GridLayout(3,1);
			panel.setLayout(layout);
			JPanel boxPanel = new JPanel();
			for(int i=0;i<boxNum;i++){
				boxs[i] = new JCheckBox(charNames[i],isChecked[i]);
				boxPanel.add(boxs[i]);
			}
			panel.add(boxPanel);
		}
	}
	private class CharPane extends Pane {
		JTextArea text;
		JButton clearButton;
		CharPane(String str) {
			super(str);
			text = new JTextArea(1,20);
			text.setText(charList[4]+charList[3]);
			clearButton = new JButton("クリア");
			text.setLineWrap(true);
			panel.add(text);
			panel.add(clearButton);
			clearButton.addActionListener(new ActionListener(){
		    public void actionPerformed(ActionEvent e) {
		    	text.setText("");
			  }
			});
		}
	}
	public void actionPerformed(ActionEvent e){
		int boxIndex=0;
		for(int i=0;i<selectPanel.boxNum;i++) {
			if(charNames[i]==e.getActionCommand()) boxIndex = i;
		}
		if(selectPanel.boxs[boxIndex].isSelected()) {
			addChar(boxIndex);
		} else {
			deleteChar(boxIndex);
		}
	}
	private void addChar(int index) {
		String existChar = charPanel.text.getText();
		for(int i=0;i<charList[index].length();i++) {
			String target = String.valueOf(charList[index].charAt(i));
			if(existChar.indexOf(target) == -1) {
				charPanel.text.setText(charPanel.text.getText()+target);
			}
		}
	}
	private void deleteChar(int index) {
		String existChar = charPanel.text.getText();
		for(int i=0;i<charList[index].length();i++) {
			String target = String.valueOf(charList[index].charAt(i));
			if(existChar.indexOf(target) != -1) {
				charPanel.text.setText(charPanel.text.getText().replace(target,""));
			}
		}
	}
}
