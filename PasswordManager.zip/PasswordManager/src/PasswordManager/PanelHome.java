package PasswordManager;

import java.awt.BorderLayout;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

import org.json.JSONArray;
import org.json.JSONObject;

@SuppressWarnings("serial")
public class PanelHome extends JPanel {
	
	static String[][] dataArray;
	DefaultTableModel model;
	
	final int COPY_COL = 3;
	final String[] column_list = {"title","update","password"};
	
	PanelHome(){

		JPanel buttonPanel = new JPanel();
		JButton button_register = new JButton("新規作成");
		
	// ボタンがクリックされたときの処理
		button_register.addActionListener(new ActionListener(){
		    public void actionPerformed(ActionEvent e) {
		    	MainFrame.frameController.toRegister();
			  }
			});
		buttonPanel.add(button_register);
    
    model = new DefaultTableModel();
    // 列名の設定
    for(int i=0;i<column_list.length;i++) {model.addColumn(column_list[i]);}
    model.addColumn("");
    
		JTable table = new JTable(model);
		// 中央揃えの設定
		DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
		centerRenderer.setHorizontalAlignment(JLabel.CENTER);
    table.getColumnModel().getColumn(COPY_COL).setCellRenderer(centerRenderer);

		JScrollPane pane = new JScrollPane(table);
//		pane.setPreferredSize(new Dimension(400, 300));
		
		JLabel label = new JLabel("");
		// 表をクリックしたときは、コピーか詳細画面
		table.addMouseListener(new java.awt.event.MouseAdapter() {
		   public void mouseClicked(MouseEvent e) {
		    int row = table.getSelectedRow();
		    int col = table.getSelectedColumn();
		    // クリップボードにコピー
		    if (col==COPY_COL) {
			    copyToClipboad((String)table.getValueAt(row, MainFrame.PASSWORD_INDEX));
			    String title = (String)table.getValueAt(row, MainFrame.TITLE_INDEX);
			    label.setText(title+"：クリップボードにコピーしました");
		    } 
		    // 詳細画面に遷移
		    else {
		    	MainFrame.frameController.toDetail(row);
		    }
		   }
		  });
		
		add(buttonPanel,BorderLayout.NORTH);
		add(pane,BorderLayout.CENTER);
		add(label,BorderLayout.SOUTH);
	}
//クリップボードにコピーするための関数
  public void copyToClipboad(String str) {
    Clipboard clipboard = Toolkit.getDefaultToolkit()
            .getSystemClipboard();
    StringSelection selection = new StringSelection(str);
    clipboard.setContents(selection, selection);
  }
  public void initPage() {
  	model.setRowCount(0);
  	JSONArray data_json = new JSONArray(MainFrame.fIO.readFile());
    int data_len = data_json.length();
		dataArray = new String[data_len][MainFrame.DATA_LENGTH];

    for (int i=0;i<data_len;i++) {
      
			JSONObject jsonObject = data_json.getJSONObject(i);
			
			dataArray[i][MainFrame.TITLE_INDEX] = jsonObject.getString("title");
			dataArray[i][MainFrame.UPDATE_INDEX] = jsonObject.getString("update");
			dataArray[i][MainFrame.MEMO_INDEX] = jsonObject.getString("memo");
			
			String[] settings = new String[2];
			for(int j=0;j<2;j++) { settings[j] = jsonObject.getJSONArray("setting").get(j).toString(); }
			dataArray[i][MainFrame.PASSWORD_INDEX] = MainFrame.cryptoEditor.genPassword(jsonObject.getString("data"), settings);
			String old_data = jsonObject.getString("old_data");
			if(!old_data.equals("")) {
				dataArray[i][MainFrame.OLD_INDEX] = MainFrame.cryptoEditor.genPassword(old_data, settings);
			} else {
				dataArray[i][MainFrame.OLD_INDEX] = "";
			}
			
			String [] row = {
					dataArray[i][MainFrame.TITLE_INDEX],
					dataArray[i][MainFrame.UPDATE_INDEX],
					dataArray[i][MainFrame.PASSWORD_INDEX],
					"(copy)"
					};
			model.addRow(row);
		}
  }
}
