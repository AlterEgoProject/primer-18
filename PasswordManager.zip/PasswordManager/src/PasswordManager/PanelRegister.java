package PasswordManager;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import org.json.JSONArray;
import org.json.JSONObject;

@SuppressWarnings("serial")
public class PanelRegister extends JPanel {
	String data;
	String[] settings;
	// 項目の表示順
	final int ROW_NUM = 4;
	final int TITLE_ROW = 0;
	final int SETTING_ROW = 1;
	final int PASSWORD_ROW = 2;
	final int MEMO_ROW = 3;
	// 項目エリアのペイン
	TextPane titlePanel;
	SettingPane settingPanel;
	LabelPane passwordPanel;
	TextPane memoPanel;
	
	PanelRegister(){
	// ボタンのエリア
		JPanel buttonPane = new JPanel();
		JButton button_update = new JButton("登録");
		buttonPane.add(button_update);
		button_update.addActionListener(new ActionListener(){
	    public void actionPerformed(ActionEvent e) {
	    	JFrame frame = new JFrame();
	    	if(titlePanel.text.getText().length()>0) {
	    		if(addData()) {
		    	JOptionPane.showMessageDialog(frame, "登録しました！");
		    	MainFrame.frameController.toHome();
	    		} else {
	    			JOptionPane.showMessageDialog(frame, "保存に失敗しました！");
	    		}
	    	} else {
	    		JOptionPane.showMessageDialog(frame, "タイトルを入力して下さい");
	    	}
		  }
		});
	// 詳細のエリア
		JPanel detailPane = new JPanel();
		GridLayout layout = new GridLayout(ROW_NUM,1);
		detailPane.setLayout(layout);

		FlowLayout flowLayout = new FlowLayout();
		flowLayout.setAlignment(FlowLayout.LEFT);
		JPanel[] layoutPanels = new JPanel[ROW_NUM];
		for(int i=0;i<ROW_NUM;i++) { 
			layoutPanels[i] = new JPanel(); 
			layoutPanels[i].setLayout(flowLayout);
		}
		
		titlePanel = new TextPane("タイトル　");
		layoutPanels[TITLE_ROW].add(titlePanel.panel);
		settingPanel = new SettingPane("　設　定　");
		layoutPanels[SETTING_ROW].add(settingPanel.panel);
		passwordPanel = new LabelPane("パスワード");
		layoutPanels[PASSWORD_ROW].add(passwordPanel.panel);
		memoPanel = new TextPane("　メ　モ　");
		layoutPanels[MEMO_ROW].add(memoPanel.panel);
		
		settingPanel.button.addActionListener(new ActionListener(){
	    public void actionPerformed(ActionEvent e) {
	    	MainFrame.frameController.toSetting();
		  }
		});
		
		for(int i=0;i<ROW_NUM;i++) { detailPane.add(layoutPanels[i]);}
		add(detailPane);
		add(buttonPane,BorderLayout.SOUTH);
	}
	
	public void initPage() {
		titlePanel.text.setText("");
		memoPanel.text.setText("");
		String[] settings = {"12","123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz#$%()*+-./:;?@[]_{}~"};
		updatePage(settings);
	}
	public void updatePage(String[] settings) {
		String data = MainFrame.cryptoEditor.genRandData();
		String password = MainFrame.cryptoEditor.genPassword(data, settings);
		passwordPanel.text.setText(password);
		this.data = data;
		this.settings = settings;
	}
//項目のためのペイン
	private class Pane {
		JPanel panel;
		Pane(String str) {
			panel = new JPanel();
			panel.add(new JLabel(str + "："));
		}
	}
	private class LabelPane extends Pane{
		JLabel text;
		LabelPane(String str) {
			super(str);
			text = new JLabel();
			panel.add(text);
		}
	}
	private class TextPane extends Pane {
		JTextField text;
		TextPane(String str) {
			super(str);
			text = new JTextField(10);
			panel.add(text);
		}
	}
	private class SettingPane extends Pane {
//		JLabel text;
		JButton button;
		SettingPane(String str) {
			super(str);
//			text = new JLabel("デフォルト");
			button = new JButton("設定の変更");
//			panel.add(text);
			panel.add(button);
		}
	}
	private boolean addData() {
		JSONObject obj = new JSONObject();
		obj.put("title", titlePanel.text.getText());
		obj.put("update", LocalDate.now().toString());
		JSONArray jsonArr = new JSONArray();
		jsonArr.put(settings[0]);
		jsonArr.put(settings[1]);
		obj.put("setting",jsonArr);
		obj.put("data",data);
		obj.put("old_data","");
		obj.put("memo",memoPanel.text.getText());
		
		JSONArray data_json = new JSONArray(MainFrame.fIO.readFile());
		data_json.put(obj);
		return MainFrame.fIO.writeFile(data_json.toString(2));
	}
}
