package PasswordManager;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Random;

public class CryptoEditor {
	private final String watchword;
	
	CryptoEditor(String watchword){
		this.watchword = watchword;
	}
	// 文字列をハッシュ値に変換
	private BigInteger genHush(String val,String str) throws NoSuchAlgorithmException  {
    MessageDigest digest = MessageDigest.getInstance("SHA-256");
    BigInteger hush_str = new BigInteger(1, digest.digest(str.getBytes()));
    BigInteger hush_add = hush_str.add(new BigInteger(val, 16));
    BigInteger hush = new BigInteger(1, digest.digest(hush_add.toByteArray())); // 再度ハッシュ化
//    System.out.println(hush.toString(16));
    return hush;
	}
	// ハッシュ値からパスワードを生成
	public String genPassword(String data,String[] settings) {
		String password = "";
		try {
			int passwordLen = Integer.parseInt(settings[0]); // 文字数
			String charList = settings[1]; // 使用文字
			BigInteger hush = genHush(data,watchword);
			int charLength = charList.length(); // 使用文字の数
	//		System.out.println(charLength);
			for(int i=0;i<passwordLen;i++) {
				BigInteger[] temp = hush.divideAndRemainder(new BigInteger(String.valueOf(charLength)));
				hush = temp[0]; // 商は次に利用
				int hush_reminder = temp[1].intValue(); // 余りをインデックスとして charList の中からパスワードを決める
				if(hush_reminder<0) hush_reminder = hush_reminder + charLength;
				password = password + charList.charAt(hush_reminder);
			}
		} catch (Exception e) {
			e.printStackTrace();
			password = "エラー：パスワード生成！";
		}
//		System.out.println(password);
		return password;
	}
	
	public String genRandData() {
		Random r = new SecureRandom();
		byte[] randamByte = new byte[32];
		r.nextBytes(randamByte); 
		StringBuilder sb = new StringBuilder();
    for (byte d: randamByte) {
        sb.append(String.format("%02x", d));
    }
    String str = sb.toString();
//    System.out.println(str);
		return str;
	}
}


