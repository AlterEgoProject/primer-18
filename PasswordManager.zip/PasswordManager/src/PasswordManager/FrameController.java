package PasswordManager;

import java.awt.CardLayout;

import javax.swing.JPanel;

public class FrameController {

	MainFrame mf;
	JPanel cardPanel;
	CardLayout layout;
	
	PanelHome home_panel;
	PanelDetail detail_panel;
	PanelRegister register_panel;
	PanelSetting setting_panel;
	
	FrameController(MainFrame mf) {
		this.mf = mf;
		
		home_panel = new PanelHome(); // ホーム画面
		detail_panel = new PanelDetail(); // 詳細画面
		register_panel = new PanelRegister(); // 登録画面
		setting_panel = new PanelSetting(); // 設定画面
		
		home_panel.setName("ホーム");
		detail_panel.setName("詳細画面");
		register_panel.setName("登録画面");
		setting_panel.setName("設定画面");

    cardPanel = new JPanel();
    layout = new CardLayout();
    cardPanel.setLayout(layout);

    cardPanel.add(home_panel, "ホーム");
    cardPanel.add(detail_panel, "詳細画面");
    cardPanel.add(register_panel, "登録画面");
    cardPanel.add(setting_panel, "設定画面");
    
    mf.getContentPane().add(cardPanel);
    mf.setVisible(true);
	}
	
	private void changePanel(String str) {
		mf.setTitle(str);
		mf.setLocationRelativeTo(null);
		layout.show(cardPanel,str);
	}
	public void toHome() {
		mf.setSize(500, 520);
		changePanel("ホーム");
		home_panel.initPage();
	}
	public void toDetail(int index) {
		mf.setSize(350, 300);
		changePanel("詳細画面");
		detail_panel.initPage(index);
	}
	public void toRegister() {
		mf.setSize(500, 300);
		changePanel("登録画面");
		register_panel.initPage();
	}
	public void registerUpdate(String[] settings) {
		mf.setSize(500, 300);
		changePanel("登録画面");
		register_panel.updatePage(settings);
	}
	public void toSetting() {
		mf.setSize(500, 400);
		changePanel("設定画面");
		setting_panel.initPage();
	}
}
