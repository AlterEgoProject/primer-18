package PasswordManager;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class PasswordManager {

		static final String FILE_NAME = "data";
		
	public static void main(String[] args) {
		
		JFrame frm = new JFrame();
		frm.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		String value = JOptionPane.showInputDialog(frm, "合言葉を入力して下さい");
		if (value == null){
    }else{
  		new MainFrame(value);
    }
		frm.dispose();
	}	
	
}