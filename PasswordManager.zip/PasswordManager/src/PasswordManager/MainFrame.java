package PasswordManager;

import java.awt.Component;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

import javax.swing.JFrame;

@SuppressWarnings("serial")
public class MainFrame extends JFrame{
	
	static final int DATA_LENGTH = 5;
	static final int TITLE_INDEX = 0;
	static final int UPDATE_INDEX = 1;
	static final int PASSWORD_INDEX = 2;
	static final int OLD_INDEX = 3;
	static final int MEMO_INDEX = 4;
	
	static CryptoEditor cryptoEditor;
	static FileIO fIO;
	static FrameController frameController;
	
	MainFrame(String watchword){
		cryptoEditor = new CryptoEditor(watchword);
		fIO = new FileIO(PasswordManager.FILE_NAME);
		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		frameController = new FrameController(this);
		frameController.toHome();
	
		addWindowListener(
		  (WindowListener) new WindowAdapter(){
		    public void windowClosing(WindowEvent e){
		    	Component[] coms = frameController.cardPanel.getComponents();
		    	for(int i=0;i<coms.length;i++) {
		    		if(coms[i].isVisible()) {
		    			if(coms[i].getName()!="ホーム") {
		    				frameController.toHome();
		    			} else {
		    				setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		    				setVisible(false);
		    				dispose();
		    			}
		    			break;
		    		}
		    	}
		    }
		  }
		);
	}
}
